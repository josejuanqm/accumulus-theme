<?php
/**
 * Popup class
 *
 * @package   PUM
 * @copyright Copyright (c) 2023, Code Atlantic LLC
 */

// Empty class extender here for backward compatibility.
class PUM_Popup extends PUM_Model_Popup {}
